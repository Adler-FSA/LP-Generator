Adler-FSA – LP-Generator SAFE TEST (v2.4.4b)
=============================================

Enthaltene Dateien
------------------
1) LP-Generator_v2.4.4b_SAFE_TEST.html
   • Eine einzelne HTML-Datei mit Dashboard, Status-Ampel und Mini-Log.
   • Prüft automatisch die URL: https://adler-fsa.github.io/tools/
   • Button „Neu-Scan“ startet den Check erneut.

Wichtige Hinweise
-----------------
• Die ZIP-Datei NICHT entpacken, wenn du sie nur im GitHub-Repo ablegen möchtest.
• Für einen Live-Test via GitHub Pages kopiere/verschiebe die HTML-Datei in dein Repo:
  /tools/LP-Generator_v2.4.4b_SAFE_TEST.html
  und rufe sie dann auf:
  https://adler-fsa.github.io/Lp-Generator/tools/LP-Generator_v2.4.4b_SAFE_TEST.html

Upload-Anleitung (GitHub Web)
-----------------------------
1. Gehe in dein Repository: https://github.com/Adler-FSA/Lp-Generator
2. Klicke auf „Add file“ → „Upload files“
3. Ziehe die ZIP-Datei hierher.
4. Commit message ausfüllen → „Commit changes“

Optional: Entpacken & Direktaufruf
----------------------------------
• Wenn du lokal testen willst, entpacke die ZIP und öffne die HTML-Datei im Browser (Doppelklick).
• Auf iPad kannst du die Datei z. B. über „Dateien“ → „In Safari öffnen“ laden.

Stand: 2025-10-06
