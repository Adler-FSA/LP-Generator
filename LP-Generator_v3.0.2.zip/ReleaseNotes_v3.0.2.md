# LP-Generator v3.0.2 – Master Template Update

**Änderungen**  
- Vollständige LP-Template-Umsetzung nach Memo 01/02  
- Erweiterungen aus Memo 03–05 integriert (Reise, Kino-Vorschau, Mentor, Social)  
- Musik-Manager mit Auto-Start (lokale Datei + externer Fallback)  
- Ampel-Logik (red/pending/approved) über `data/emails.json`  
- DSGVO-konforme Datenströme (keine personenbezogenen Daten in URL, kein LocalStorage)  
- Media-Admin & LP-Admin im Rota-Style (JSON-gesteuert)

**Dateistruktur**
- `lp-template.html`, `lp-admin.html`, `media-admin.html`, `index.html`
- `assets/mentor-icon.svg`, `assets/mp3/terra-mater.mp3` (Placeholder – bitte echte MP3 ersetzen, falls gewünscht)
- `data/settings.json`, `data/emails.json`, `data/quotes.json`, `data/slideshow.json`, `data/music.json`, `data/kino.json`, `data/reise.json`
