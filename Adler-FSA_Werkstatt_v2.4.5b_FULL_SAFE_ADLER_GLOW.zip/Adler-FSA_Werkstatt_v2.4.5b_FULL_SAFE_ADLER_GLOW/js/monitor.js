
(function(){
  const CHECK_URL = "https://adler-fsa.github.io/tools/";
  const state = document.getElementById('ws-state');
  const modules = document.getElementById('ws-modules');
  const restart = document.getElementById('ws-restart');
  const infoBtn = document.getElementById('toggle-info');
  const infoBox = document.getElementById('ws-info');
  const logBody = document.getElementById('log-body');

  const log = (msg, level='ok') => {
    const time = new Date().toLocaleTimeString();
    const el = document.createElement('div');
    el.className = level;
    const icon = level==='ok'?'✅':(level==='warn'?'⚠️':'❌');
    el.textContent = `[${time}] ${icon} ${msg}`;
    logBody.appendChild(el);
    logBody.scrollTop = logBody.scrollHeight;
  };

  const setWarn = (txt) => { state.textContent = txt; state.className = 'status-warn'; };
  const setOk   = (txt) => { state.textContent = txt; state.className = 'status-ok'; };
  const setErr  = (txt) => { state.textContent = txt; state.className = 'status-err'; };

  infoBtn.onclick = () => {
    const open = infoBox.style.display === 'block';
    infoBox.style.display = open ? 'none' : 'block';
    infoBtn.textContent = open ? '▼ Funktionsübersicht' : '▲ Schließen';
  };

  async function checkPages() {
    setWarn('Scan läuft…');
    log(`Starte Check auf ${CHECK_URL}`,'warn');
    try {
      const resp = await fetch(CHECK_URL, { cache: 'no-store' });
      if (!resp.ok) throw new Error('HTTP '+resp.status);
      const html = await resp.text();
      if (html.includes('404') || html.toLowerCase().includes('not found')) {
        setWarn('GitHub Pages im Neuaufbau – bitte 2–3 Min warten');
        log('Pages liefert 404/„not found“ (Deploy läuft)','warn');
      } else {
        setOk('Aktiv');
        log('GitHub Pages online und aktiv','ok');
      }
    } catch (e) {
      setErr('GitHub Pages nicht erreichbar');
      log('Fehler beim Abruf: '+e.message,'err');
    }
  }

  restart.onclick = () => { checkPages(); };
  checkPages();
})();
