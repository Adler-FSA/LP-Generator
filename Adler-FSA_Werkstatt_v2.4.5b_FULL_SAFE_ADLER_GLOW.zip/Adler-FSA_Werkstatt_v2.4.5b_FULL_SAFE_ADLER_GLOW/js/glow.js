
(function(){
  const logo = document.querySelector('.adler-logo');
  if (!logo) return;
  logo.classList.add('adler-breathe');
})();
