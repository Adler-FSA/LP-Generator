Adler-FSA Werkstatt v2.4.5b – FULL SAFE ADLER GLOW
====================================================

Was ist das?
------------
Eine komplett lauffähige, autarke Werkstatt-Startseite mit:
• Gold-Adler (ruhiger Atem-Glow)
• Dashboard (Status, Module, Neu-Scan)
• Funktionsübersicht (aufklappbar)
• Mini-Log (unten links)
• Auto-Start-Check gegen: https://adler-fsa.github.io/tools/

So lädst du es hoch (GitHub, iPad-freundlich)
---------------------------------------------
1) GitHub öffnen → Repo: Adler-FSA / Lp-Generator
2) Add file → Upload files
3) Den gesamten Ordner als ZIP **nicht entpackt** hochladen
4) Commit changes

Seite aufrufen (nach ~1–2 Minuten):
-----------------------------------
https://adler-fsa.github.io/Adler-FSA_Werkstatt_v2.4.5b_FULL_SAFE_ADLER_GLOW/

Stand: 2025-10-06
